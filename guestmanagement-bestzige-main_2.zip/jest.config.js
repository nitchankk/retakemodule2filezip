module.exports = {
  testEnvironment: 'jsdom'
}
